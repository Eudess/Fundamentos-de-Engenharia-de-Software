<?php
if (isset($_POST['nome']) && isset($_POST['cargo']) && isset($_POST['email']) && isset($_POST['telefone'])) {
	// include Database connection file
	include "db_connection.php";

	// get values
	$nome = $_POST['nome'];
	$cargo = $_POST['cargo'];
	$email = $_POST['email'];
	$telefone = $_POST['telefone'];

	$query = "INSERT INTO funcionarios(nome, cargo, email, telefone) VALUES('$nome', '$cargo', '$email', '$telefone')";
	if (!$result = mysql_query($query)) {
		exit(mysql_error());
	}
	echo "1 Record Added!";
}
?>