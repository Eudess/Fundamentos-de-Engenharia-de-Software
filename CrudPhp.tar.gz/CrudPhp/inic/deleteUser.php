<?php
// check request
if (isset($_POST['id']) && isset($_POST['id']) != "") {
	// include Database connection file
	include "db_connection.php";

	// get user id
	$funcionarios_id = $_POST['id'];

	// delete User
	$query = "DELETE FROM funcionarios WHERE id = '$funcionarios_id'";
	if (!$result = mysql_query($query)) {
		exit(mysql_error());
	}
}
?>
