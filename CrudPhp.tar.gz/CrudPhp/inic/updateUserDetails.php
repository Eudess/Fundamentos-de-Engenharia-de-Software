<?php
// include Database connection file
include "db_connection.php";

// check request
if (isset($_POST)) {
	// get values
	$id = $_POST['id'];
	$nome = $_POST['nome'];
	$cargo = $_POST['cargo'];
	$email = $_POST['email'];
	$telefone = $_POST['telefone'];

	// Updaste User details
	$query = "UPDATE funcionarios SET nome = '$nome', cargo = '$cargo', email = '$email', telefone = '$telefone' WHERE id = '$id'";
	if (!$result = mysql_query($query)) {
		exit(mysql_error());
	}
}