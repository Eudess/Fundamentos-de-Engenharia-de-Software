// Add Record
function addRecord() {
    // get values
    var nome = $("#nome").val();
    var cargo = $("#cargo").val();
    var email = $("#email").val();
    var telefone = $("#telefone").val();

    // Add record
    $.post("inic/addRecord.php", {
        nome: nome,
        cargo: cargo,
        email: email,
        telefone: telefone
    }, function (data, status) {
        // close the popup
        $("#add_new_record_modal").modal("hide");

        // read records again
        readRecords();

        // clear fields from the popup
        $("#nome").val("");
        $("#cargo").val("");
        $("#email").val("");
        $("#telefone").val("");
    });
}

// READ records
function readRecords() {
    $.get("inic/readRecords.php", {}, function (data, status) {
        $(".records_content").html(data);
    });
}


function DeleteUser(id) {
    var conf = confirm("Tem certeza de que deseja excluir o usuário?");
    if (conf == true) {
        $.post("inic/deleteUser.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                readRecords();
            }
        );
    }
}

function GetUserDetails(id) {
    // Add User ID to the hidden field for furture usage
    $("#hidden_funcionarios_id").val(id);
    $.post("inic/readUserDetails.php", {
            id: id
        },
        function (data, status) {
            // PARSE json data
            var user = JSON.parse(data);
            // Assing existing values to the modal popup fields
            $("#update_nome").val(funcionarios.nome);
            $("#update_cargo").val(funcionarios.cargo);
            $("#update_email").val(funcionarios.email);
            $("#update_telefone").val(funcionarios.telefone);
        }
    );
    // Open modal popup
    $("#update_funcionarios_modal").modal("show");
}

function UpdateUserDetails() {
    // get values
    var nome = $("#update_nome").val();
    var cargo = $("#update_cargo").val();
    var email = $("#update_email").val();
    var telefone = $("#update_telefone").val();

    // get hidden field value
    var id = $("#hidden_funcionarios_id").val();

    // Update the details by requesting to the server using ajax
    $.post("inic/updateUserDetails.php", {
            id: id,
            nome: nome,
            cargo: cargo,
            email: email,
            telefone: telefone
        },
        function (data, status) {
            // hide modal popup
            $("#update_funcionarios_modal").modal("hide");
            // reload Users by using readRecords();
            readRecords();
        }
    );
}

$(document).ready(function () {
    // READ recods on page load
    readRecords(); // calling function
});
